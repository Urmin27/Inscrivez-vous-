<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $email = htmlspecialchars($_POST['email']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $fiteny = htmlspecialchars($_POST['fiteny']);

    $to = "horlandobe@gmail.com";
    $subject = "Nouvelle inscription";
    $message = "Anarana: $nom\nFanampiny: $prenom\nEmail: $email\nLaharana: $telephone\nFiteny: $fiteny";
    $headers = "From: $email";

    if (mail($to, $subject, $message, $headers)) {
        echo "Misaotra! Nandefa ny vaovao tamim-pahombiazana.";
    } else {
        echo "Misy olana tamin'ny fandefasana ny email.";
    }
} else {
    echo "Tsy misy data alefa.";
}
?>
